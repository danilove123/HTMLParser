package com.company.All;

import javax.swing.filechooser.FileFilter;
import java.io.File;

public class HTMLFileFilter extends FileFilter {
    public HTMLFileFilter() {
        super();
    }
    @Override
    public boolean accept(File f) {
        if(f.isDirectory()){return true;}
        if(!f.isDirectory()){
            return f.getName().endsWith(".html") | f.getName().endsWith(".htm")|f.getName().toLowerCase().endsWith(".html") | f.getName().toLowerCase().endsWith(".htm");
        }
        return false;
    }
    @Override
    public String getDescription() {
        return  "HTML и HTM файлы";
    }
}
