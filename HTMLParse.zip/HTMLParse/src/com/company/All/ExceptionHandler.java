package com.company.All;

public class ExceptionHandler {
    public static void log(Exception e){
        System.out.println(e.toString());
    }
}
