package com.company.All;


import com.company.All.listeners.UndoListener;

import javax.swing.*;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import java.io.*;

public class Controller {
    private View view;
    private HTMLDocument document;
    private File currentFile;
    public void setPlainText(String text){
       resetDocument();
       StringReader str=new StringReader(text);
       HTMLEditorKit ht=new HTMLEditorKit();
       try {
           ht.read(str,document,0);
       }
       catch (Exception e){
           ExceptionHandler.log(e);
       }
    }
    public String getPlainText(){
        StringWriter t=new StringWriter();

        try{
            HTMLEditorKit ht=new HTMLEditorKit();
            ht.write(t,document,0,document.getLength());
            return ht.getAccessibleContext().getAccessibleEditableText().toString();
        }
        catch (Exception e){
            ExceptionHandler.log(e);
        }
//        return ht.getAccessibleContext().getAccessibleText().toString();
        return t.toString();
    }
    public HTMLDocument getDocument() {
        return document;
    }

    public Controller(View view) {
        this.view = view;
    }
    public void createNewDocument(){
        view.selectHtmlTab();
        resetDocument();
        view.setTitle("HTML редактор");
        view.resetUndo();
        currentFile=null;
    }
    public void openDocument(){
        view.selectHtmlTab();
        JFileChooser jf=new JFileChooser();
        jf.setFileFilter(new HTMLFileFilter());
        if(jf.showOpenDialog(view)==JFileChooser.APPROVE_OPTION){
            currentFile = jf.getSelectedFile();
            resetDocument();
            view.setTitle(currentFile.getName());
            try {
                FileReader fw = new FileReader(currentFile);
                HTMLEditorKit ht = new HTMLEditorKit();
                ht.read(fw, document, 0);
                view.resetUndo();
                fw.close();
            } catch (Exception e) {
                ExceptionHandler.log(e);
            }
        }

    }
    public void saveDocument(){
        view.selectHtmlTab();
        if(currentFile==null){
            saveDocumentAs();
        }
        else {
            try {
                FileWriter fw = new FileWriter(currentFile);
                HTMLEditorKit ht = new HTMLEditorKit();
                ht.write(fw, document, 0, document.getLength());
                fw.close();
            } catch (Exception e) {
                ExceptionHandler.log(e);
            }
        }
    }
    public void saveDocumentAs(){
        view.selectHtmlTab();
        JFileChooser jf=new JFileChooser();
        jf.setFileFilter(new HTMLFileFilter());
        if(jf.showSaveDialog(view)==JFileChooser.APPROVE_OPTION) {
            currentFile = jf.getSelectedFile();
            view.setTitle(currentFile.getName());

            try {
                FileWriter fw = new FileWriter(currentFile);
                HTMLEditorKit ht = new HTMLEditorKit();
                ht.write(fw, document, 0, document.getLength());
                fw.close();
            } catch (Exception e) {
                ExceptionHandler.log(e);
            }
        }

    }
    public static void main(String[] args) {
        View view=new View();
        Controller controller=new Controller(view);
        view.setController(controller);
        view.init();
        controller.init();
    }
    public void init(){
        createNewDocument();
    }
    public void resetDocument(){
        if(document!=null) {
            UndoListener ud = view.getUndoListener();
            document.removeUndoableEditListener(ud);
        }
            HTMLEditorKit e= new HTMLEditorKit();
            document=(HTMLDocument) e.createDefaultDocument();
            document.addUndoableEditListener(view.getUndoListener());
            view.update();

    }
    public void exit(){
        System.exit(0);
    }
}
