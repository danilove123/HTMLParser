package com.company.All;


import com.company.All.listeners.FrameListener;
import com.company.All.listeners.TabbedPaneChangeListener;
import com.company.All.listeners.UndoListener;

import javax.swing.*;
import javax.swing.undo.UndoManager;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class View extends JFrame implements ActionListener {
    private Controller controller;
    private final UndoManager undoManager=new UndoManager();
    private final UndoListener undoListener=new UndoListener(undoManager);
    private final JTabbedPane tabbedPane=new JTabbedPane();
    private final JTextPane htmlTextPane=new JTextPane();
    private final JEditorPane plainTextPane=new JEditorPane();
    public Controller getController() {
        return controller;
    }
    public boolean isHtmlTabSelected(){
        return tabbedPane.getSelectedIndex()==0;
    }
    public void update(){
        htmlTextPane.setDocument(controller.getDocument());
    }
    public void showAbout(){
        JOptionPane.showMessageDialog(this,"Some information","Ок", JOptionPane.INFORMATION_MESSAGE);
    }
    public void selectHtmlTab(){
        tabbedPane.setSelectedIndex(0);
        resetUndo();
    }
    public View()  {
        try {
            UIManager.setLookAndFeel(UIManager.getLookAndFeel());
        }
        catch (Exception e){
            ExceptionHandler.log(e);
        }

    }

    public void initMenuBar(){
        JMenuBar jMenuBar=new JMenuBar();
        MenuHelper.initFileMenu(this,jMenuBar);
        MenuHelper.initEditMenu(this,jMenuBar);
        MenuHelper.initStyleMenu(this,jMenuBar);
        MenuHelper.initAlignMenu(this,jMenuBar);
        MenuHelper.initColorMenu(this,jMenuBar);
        MenuHelper.initFontMenu(this,jMenuBar);
        MenuHelper.initHelpMenu(this,jMenuBar);
        this.getContentPane().add(jMenuBar,BorderLayout.NORTH);
    }
    public void selectedTabChanged(){
        switch (tabbedPane.getSelectedIndex()) {
            case 0:
                controller.setPlainText(plainTextPane.getText());
                break;
            case 1:
                plainTextPane.setText(controller.getPlainText());
                break;
        }
        resetUndo();
    }
    public void initEditor(){
        htmlTextPane.setContentType("text/html");
        JScrollPane js=new JScrollPane(htmlTextPane);
        tabbedPane.add("HTML",js);
        JScrollPane js1=new JScrollPane(plainTextPane);
        tabbedPane.add("Текст",js1);
        tabbedPane.setPreferredSize(this.getPreferredSize());
        TabbedPaneChangeListener tp=new TabbedPaneChangeListener(this);
        tabbedPane.addChangeListener(tp);
        this.getContentPane().add(tabbedPane,BorderLayout.CENTER);
    }
    public void initGui(){
        initEditor();
        initMenuBar();
        pack();
    }
    public boolean canUndo(){return  undoManager.canUndo();}
    public boolean canRedo(){
        return undoManager.canRedo();
    }
    public void setController(Controller controller) {
        this.controller = controller;
    }

    public void init(){
        initGui();
        FrameListener fr=new FrameListener(this);
        this.addWindowListener(fr);
        this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            case "Новый":
                controller.createNewDocument();
                break;
            case "Открыть":
                controller.openDocument();
                break;
            case "Сохранить":
                controller.saveDocument();
                break;
            case "Сохранить как...":
                controller.saveDocumentAs();
                break;
            case "Выход":
                controller.exit();
                break;
            case "О программе":
                showAbout();
                break;
            default:
                System.out.println(" hi");
        }

    }
    public void exit(){
        controller.exit();
    }
    public void resetUndo(){
        undoManager.discardAllEdits();
    }
    public void undo(){
        try{
            undoManager.undo();
        }
        catch (Exception e){
            ExceptionHandler.log(e);
        }
    }
    public void redo(){
        try{
            undoManager.redo();
        }
        catch (Exception e){
            ExceptionHandler.log(e);
        }
    }

    public UndoListener getUndoListener() {
        return undoListener;
    }
}
